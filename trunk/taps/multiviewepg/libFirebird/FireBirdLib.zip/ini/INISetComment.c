#include "FBLib_ini.h"
#include "../libFireBird.h"

//---------------------------------------  INISetComment --------------------------------
//
void INISetComment (char *Comment)
{
  (void) Comment;
}
