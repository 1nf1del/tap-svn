#include "../libFireBird.h"

dword HDD_LiveFS_GetRootDirAddress (void)
{
  return FIS_vHDDLiveFSRootDir();
}
