#include "FBLib_hdd.h"

void Delay (dword Loops)
{
  while (Loops > 0) Loops--;
}
