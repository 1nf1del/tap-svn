#ifndef FBLIB_SHUTDOWN_H
#define FBLIB_SHUTDOWN_H

#include "tap.h"

#define HDDIDLE         0xe1

extern bool LibInitialized;

#endif
