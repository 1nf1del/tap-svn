#include "tap.h"

volatile dword *EMMA_TCAM = (dword *) 0xb20111c4;
