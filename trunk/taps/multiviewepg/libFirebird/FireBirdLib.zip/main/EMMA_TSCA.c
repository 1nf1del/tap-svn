#include "tap.h"

volatile dword *EMMA_TSCA = (dword *) 0xb2010e30;
