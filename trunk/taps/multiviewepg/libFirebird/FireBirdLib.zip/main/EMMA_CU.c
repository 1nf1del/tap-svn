#include "tap.h"

volatile dword *EMMA_CU = (dword *) 0xb0012900;
