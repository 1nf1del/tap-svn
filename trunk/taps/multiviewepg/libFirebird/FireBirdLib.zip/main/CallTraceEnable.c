#include                "FBLib_main.h"

void CallTraceEnable (bool Enable)
{
  CallTraceEnabled = Enable;
}
