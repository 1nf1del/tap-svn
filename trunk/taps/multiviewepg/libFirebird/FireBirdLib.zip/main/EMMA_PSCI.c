#include "tap.h"

volatile dword *EMMA_PSCI1_b2005000 = (dword *) 0xb2005000;
volatile dword *EMMA_PSCI1_b2005010 = (dword *) 0xb2005010;
volatile dword *EMMA_PSCI1_b2005020 = (dword *) 0xb2005020;
volatile dword *EMMA_PSCI1_b2005030 = (dword *) 0xb2005030;
volatile dword *EMMA_PSCI1_b2005040 = (dword *) 0xb2005040;
volatile dword *EMMA_PSCI1_b2005050 = (dword *) 0xb2005050;
volatile dword *EMMA_PSCI1_b2005070 = (dword *) 0xb2005070;
volatile dword *EMMA_PSCI1_b2005080 = (dword *) 0xb2005080;
volatile dword *EMMA_PSCI1_b20050a0 = (dword *) 0xb20050a0;
volatile dword *EMMA_PSCI1_b20050b0 = (dword *) 0xb20050b0;
volatile dword *EMMA_PSCI1_b20050c0 = (dword *) 0xb20050c0;
volatile dword *EMMA_PSCI1_b20050d0 = (dword *) 0xb20050d0;
volatile dword *EMMA_PSCI1_b20050e0 = (dword *) 0xb20050e0;
volatile dword *EMMA_PSCI1_b2005140 = (dword *) 0xb2005140;
volatile dword *EMMA_PSCI1_b2005160 = (dword *) 0xb2005160;

volatile dword *EMMA_PSCI2_b2006060 = (dword *) 0xb2006060;
volatile dword *EMMA_PSCI2_b2006090 = (dword *) 0xb2006090;
