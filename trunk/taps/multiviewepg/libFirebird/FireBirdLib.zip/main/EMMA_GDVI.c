#include "tap.h"

volatile dword *EMMA_GDVI = (dword *) 0xb0006800;;
