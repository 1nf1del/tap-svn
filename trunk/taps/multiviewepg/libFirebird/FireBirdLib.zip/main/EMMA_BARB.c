#include "tap.h"

//BARB
volatile dword *EMMA_BARB = (dword *) 0xb0000200;
