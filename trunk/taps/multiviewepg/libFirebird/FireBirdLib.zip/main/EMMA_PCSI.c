#include "tap.h"

volatile dword *EMMA_PCSI_b200a000 = (dword *) 0xb200a000;
