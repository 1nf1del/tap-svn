#include "tap.h"

volatile dword *EMMA_ZECT_b2010600 = (dword *) 0xb2010600;
volatile dword *EMMA_ZECT_b2010604 = (dword *) 0xb2010604;
volatile dword *EMMA_ZECT_b2010608 = (dword *) 0xb2010608;
