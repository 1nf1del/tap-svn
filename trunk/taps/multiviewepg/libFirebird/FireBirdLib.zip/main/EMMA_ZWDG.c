#include "tap.h"

volatile dword *EMMA_ZWDG_b2010a00 = (dword *) 0xb2010a00;
