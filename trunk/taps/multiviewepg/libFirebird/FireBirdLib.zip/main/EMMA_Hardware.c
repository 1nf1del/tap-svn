#include "tap.h"

volatile dword *EMMA_Hardware_b000b000 = (dword *) 0xb000b000;
volatile dword *EMMA_Hardware_b000b00c = (dword *) 0xb000b00c;
volatile dword *EMMA_Hardware_b000b09c = (dword *) 0xb000b09c;
