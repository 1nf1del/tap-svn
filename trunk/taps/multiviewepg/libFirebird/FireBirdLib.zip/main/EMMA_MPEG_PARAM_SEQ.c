#include "tap.h"

//MPEG = MPEG Decoder
volatile dword *EMMA_MPEG_PARAM_SEQ = (dword *) 0xb0002280;
