#include "tap.h"

volatile dword *EMMA_TDSC_b2010c30 = (dword *) 0xb2010c30;
volatile dword *EMMA_TDSC_b2010c34 = (dword *) 0xb2010c34;
