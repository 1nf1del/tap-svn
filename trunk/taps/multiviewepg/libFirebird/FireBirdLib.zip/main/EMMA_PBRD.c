#include "tap.h"

volatile dword *EMMA_PBRD = (dword *) 0xb2000000;
