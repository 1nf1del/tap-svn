#include "tap.h"

//GBLT
volatile dword *EMMA_GBLT_b0006000 = (dword *) 0xb0006000;
volatile dword *EMMA_GBLT_b0006004 = (dword *) 0xb0006004;
volatile dword *EMMA_GBLT_b0006008 = (dword *) 0xb0006008;
volatile dword *EMMA_GBLT_b000600c = (dword *) 0xb000600c;
volatile dword *EMMA_GBLT_b0006010 = (dword *) 0xb0006010;
volatile dword *EMMA_GBLT_b0006014 = (dword *) 0xb0006014;
volatile dword *EMMA_GBLT_b0006018 = (dword *) 0xb0006018;
volatile dword *EMMA_GBLT_b000601c = (dword *) 0xb000601c;
volatile dword *EMMA_GBLT_b0006020 = (dword *) 0xb0006020;
volatile dword *EMMA_GBLT_b0006024 = (dword *) 0xb0006024;
volatile dword *EMMA_GBLT_b0006028 = (dword *) 0xb0006028;
volatile dword *EMMA_GBLT_b000602c = (dword *) 0xb000602c;
volatile dword *EMMA_GBLT_b0006030 = (dword *) 0xb0006030;
volatile dword *EMMA_GBLT_b0006034 = (dword *) 0xb0006034;
volatile dword *EMMA_GBLT_b0006038 = (dword *) 0xb0006038;
volatile dword *EMMA_GBLT_b000603c = (dword *) 0xb000603c;
volatile dword *EMMA_GBLT_b0006040 = (dword *) 0xb0006040;
volatile dword *EMMA_GBLT_b0006044 = (dword *) 0xb0006044;
volatile dword *EMMA_GBLT_b0006048 = (dword *) 0xb0006048;
volatile dword *EMMA_GBLT_b000604c = (dword *) 0xb000604c;
volatile dword *EMMA_GBLT_b0006050 = (dword *) 0xb0006050;
volatile dword *EMMA_GBLT_b0006054 = (dword *) 0xb0006054;
volatile dword *EMMA_GBLT_b0006058 = (dword *) 0xb0006058;
volatile dword *EMMA_GBLT_b000605c = (dword *) 0xb000605c;
volatile dword *EMMA_GBLT_b0006060 = (dword *) 0xb0006060;
volatile dword *EMMA_GBLT_b0006064 = (dword *) 0xb0006064;
volatile dword *EMMA_GBLT_b0006068 = (dword *) 0xb0006068;
volatile dword *EMMA_GBLT_b000606c = (dword *) 0xb000606c;
volatile dword *EMMA_GBLT_b0006074 = (dword *) 0xb0006074;
volatile dword *EMMA_GBLT_b0006078 = (dword *) 0xb0006078;
volatile dword *EMMA_GBLT_b000607c = (dword *) 0xb000607c;
volatile dword *EMMA_GBLT_b0006080 = (dword *) 0xb0006080;
volatile dword *EMMA_GBLT_b0006084 = (dword *) 0xb0006084;
volatile dword *EMMA_GBLT_b0006088 = (dword *) 0xb0006088;
volatile dword *EMMA_GBLT_b000608c = (dword *) 0xb000608c;
