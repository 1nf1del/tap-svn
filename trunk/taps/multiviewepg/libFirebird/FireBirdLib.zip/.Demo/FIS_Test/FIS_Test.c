#include "tap.h"
#include "../../libFireBird.h"

#define PROGRAM_NAME    "FIS_Test"
#define LOGNAME         "FIS_Test.log"


TAP_ID(1);
TAP_PROGRAM_NAME        (PROGRAM_NAME);
TAP_AUTHOR_NAME         ("FireBird");
TAP_DESCRIPTION         ("");
TAP_ETCINFO             (__DATE__);

char                    puffer[256];
#define DEBUG(...)      {sprintf(puffer, __VA_ARGS__); Log (LOGNAME, PROGRAM_NAME, TRUE, TIMESTAMP_HMS, puffer);}

dword TAP_EventHandler (word event, dword param1, dword param2)
{
  (void) event;
  (void) param2;

  return param1;
}

extern int              _appl_version;

int TAP_Main (void)
{
  word                  SystemID = *((volatile word*)0xa3fffffa);

  DEBUG ("SysID=%d, ApplID=%4.4x, FWgp=%8.8x", SystemID, _appl_version, FIS_GetGP((dword*)0x80000000));


  DEBUG ("FIS_fwAddEventHandler             = %8.8x", FIS_fwAddEventHandler());
  DEBUG ("FIS_fwBIOS                        = %8.8x", FIS_fwBIOS());
  DEBUG ("FIS_fwDelEventHandler             = %8.8x", FIS_fwDelEventHandler());
  DEBUG ("FIS_fwEnqueueEvent                = %8.8x", FIS_fwEnqueueEvent());
  DEBUG ("FIS_fwFlashEraseSector            = %8.8x", FIS_fwFlashEraseSector());
  DEBUG ("FIS_fwFlashFindSectorAddressIndex = %8.8x", FIS_fwFlashFindSectorAddressIndex());
  DEBUG ("FIS_fwFlashGetSectorAddress       = %8.8x", FIS_fwFlashGetSectorAddress());
  DEBUG ("FIS_fwFWFlashProgram              = %8.8x", FIS_fwFWFlashProgram());
  DEBUG ("FIS_fwGetMPVFDDataBuffer          = %8.8x", FIS_fwGetMPVFDDataBuffer());
  DEBUG ("FIS_fwMemMonitor                  = %8.8x", FIS_fwMemMonitor());
  DEBUG ("FIS_fwMHEGDisable                 = %8.8x", FIS_fwMHEGDisable());
  DEBUG ("FIS_fwMHEGStatus                  = %8.8x", FIS_fwMHEGStatus());
  DEBUG ("FIS_fwMoveOld                     = %8.8x", FIS_fwMoveOld());
  DEBUG ("FIS_fwObtainResource              = %8.8x", FIS_fwObtainResource());
  DEBUG ("FIS_fwPIC2_ISR18                  = %8.8x", FIS_fwPIC2_ISR18());
  DEBUG ("FIS_fwReboot                      = %8.8x", FIS_fwReboot());
  DEBUG ("FIS_fwReleaseResource             = %8.8x", FIS_fwReleaseResource());
  DEBUG ("FIS_fwSendToFP                    = %8.8x", FIS_fwSendToFP());
  DEBUG ("FIS_fwSendToLEDDisplay            = %8.8x", FIS_fwSendToLEDDisplay());
  DEBUG ("FIS_fwSetLEDByMode                = %8.8x", FIS_fwSetLEDByMode());
  DEBUG ("FIS_fwSetPlaybackMode             = %8.8x", FIS_fwSetPlaybackMode());
  DEBUG ("FIS_fwSetPlaybackSpeed            = %8.8x", FIS_fwSetPlaybackSpeed());
  DEBUG ("FIS_fwSetVFDByMode                = %8.8x", FIS_fwSetVFDByMode());
  DEBUG ("FIS_fwShutdown                    = %8.8x", FIS_fwShutdown());
  DEBUG ("FIS_fwStopDisplayUpdateTimers     = %8.8x", FIS_fwStopDisplayUpdateTimers());
  DEBUG ("FIS_fwTAPStart                    = %8.8x", FIS_fwTAPStart());
  DEBUG ("FIS_fwWriteSectorsDMA             = %8.8x", FIS_fwWriteSectorsDMA());

  DEBUG ("");

  DEBUG ("FIS_vEEPROM                       = %8.8x", FIS_vEEPROM());
  DEBUG ("FIS_vEventHandlerMap              = %8.8x", FIS_vEventHandlerMap());
  DEBUG ("FIS_vFlash                        = %8.8x", FIS_vFlash());
  DEBUG ("FIS_vGMT                          = %8.8x", FIS_vGMT());
  DEBUG ("FIS_vHddInfoStructure1            = %8.8x", FIS_vHddInfoStructure1());
  DEBUG ("FIS_vHddInfoStructure2            = %8.8x", FIS_vHddInfoStructure2());
  DEBUG ("FIS_vHDDLiveFSFAT1                = %8.8x", FIS_vHDDLiveFSFAT1());
  DEBUG ("FIS_vHDDLiveFSRootDir             = %8.8x", FIS_vHDDLiveFSRootDir());
  DEBUG ("FIS_vHDDLiveFSSupperblock         = %8.8x", FIS_vHDDLiveFSSupperblock());
  DEBUG ("FIS_vHDDShutdown                  = %8.8x", FIS_vHDDShutdown());
  DEBUG ("FIS_vHeapMap                      = %8.8x", FIS_vHeapMap());
  DEBUG ("FIS_vHeapStart                    = %8.8x", FIS_vHeapStart());
  DEBUG ("FIS_vKeyMap                       = %8.8x", FIS_vKeyMap());
  DEBUG ("FIS_vOSDMap                       = %8.8x", FIS_vOSDMap());
  DEBUG ("FIS_vPinStatus                    = %8.8x", FIS_vPinStatus());
  DEBUG ("FIS_vPlaybackPaused               = %8.8x", FIS_vPlaybackPaused());
  DEBUG ("FIS_vPlaySlot                     = %8.8x", FIS_vPlaySlot());
  DEBUG ("FIS_vRecFile0                     = %8.8x", FIS_vRecFile(0));
  DEBUG ("FIS_vRecFile1                     = %8.8x", FIS_vRecFile(1));
  DEBUG ("FIS_vRECSlotAddress0              = %8.8x", FIS_vRECSlotAddress(0));
  DEBUG ("FIS_vRECSlotAddress1              = %8.8x", FIS_vRECSlotAddress(1));
  DEBUG ("FIS_vSuppressedAutoStart          = %8.8x", FIS_vSuppressedAutoStart());
  DEBUG ("FIS_vSysOsdControl                = %8.8x", FIS_vSysOsdControl());
  DEBUG ("FIS_vTAP_Vfd_Control              = %8.8x", FIS_vTAP_Vfd_Control());
  DEBUG ("FIS_vTAP_Vfd_Status               = %8.8x", FIS_vTAP_Vfd_Status());
  DEBUG ("FIS_vTAPTable                     = %8.8x", FIS_vTAPTable());
  DEBUG ("FIS_vTaskAddressTable             = %8.8x", FIS_vTaskAddressTable());
  DEBUG ("FIS_vWD1                          = %8.8x", FIS_vWD1());


  return 0;
}
