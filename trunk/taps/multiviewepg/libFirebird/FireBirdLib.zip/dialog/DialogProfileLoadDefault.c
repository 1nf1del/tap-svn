#include                "FBLib_dialog.h"

void DialogProfileLoadDefault (void)
{
  DialogProfileLoad(DEFAULTPROFILE, NULL);
}
