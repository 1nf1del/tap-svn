#ifndef FBLIB_REC_H
#define FBLIB_REC_H

#include                "../libFireBird.h"

#define PCRSECTORS  900

extern tRECSlot         *RECSlot [2];
extern bool             LibInitialized;

bool getRECSlotAddress (void);

#endif
