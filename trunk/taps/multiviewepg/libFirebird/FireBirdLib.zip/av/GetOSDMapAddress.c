#include "FBLib_av.h"
#include "../libFireBird.h"

dword GetOSDMapAddress (void)
{
  return FIS_vOSDMap();
}
