#ifndef FBLIB_STRING_H
#define FBLIB_STRING_H

#include "../libFireBird.h"

bool isLegalChar(unsigned char, eRemoveChars);
char *stricstr(const char *, const char *);

#endif
